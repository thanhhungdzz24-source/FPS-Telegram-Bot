import os
import shutil
import subprocess
import telebot

TOKEN = ' 8896134144:AAF_jpc5f2ZCz4c5Zw-YP2G0-KmTHbGak_c '
bot = telebot.TeleBot(TOKEN)
M_FILE_PATH = '/workspaces/build/bot_make_fps_theos-main/FPSDisplay.m'
BACKUP_FILE_PATH = '/workspaces/build/bot_make_fps_theos-main/FPSDisplay_backup.m'

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Chào Mày, Tao Là Bot Chuyên Độ FPS Cho Theos Đây\n\n"
                          "Gõ /fps {Tên_FPS} Để Tao Đổi Tên FPS Rồi Build Luôn Cho Mày\n"
                          "Nhanh Gọn, Khỏi Lằng Nhằng")

@bot.message_handler(commands=['fps'])
def handle_fps(message):
    try:
        args = message.text.split(' ')
        if len(args) != 2:
            bot.reply_to(message, "Ơ Mày, Tên FPS Đâu. Gõ Kiểu Này Nè /fps {Tên_FPS}")
            return

        fps_name = args[1]
        backup_m_file()
        modify_m_file(fps_name)
        msg = bot.reply_to(message, "Đang Cày, Ngồi Đợi Xíu Nha Mày")
        run_make_commands(msg)
        send_dylib_file(message, msg, fps_name)
        restore_m_file()

    except Exception as e:
        bot.reply_to(message, f"Toang Rồi Mày Ơi {e}")

def backup_m_file():
    shutil.copy(M_FILE_PATH, BACKUP_FILE_PATH)

def restore_m_file():
    shutil.copy(BACKUP_FILE_PATH, M_FILE_PATH)

def modify_m_file(fps_name):
    with open(M_FILE_PATH, 'r') as file:
        content = file.read()
    new_content = content.replace(
        '@" %d FPS | %@ | Pin: %0.0f  Hello World "',
        f'@" %d FPS | %@ | Pin: %0.0f  {fps_name}"'
    )
    with open(M_FILE_PATH, 'w') as file:
        file.write(new_content)

def run_make_commands(msg):
    subprocess.run(['make', 'clean'], cwd=os.path.dirname(M_FILE_PATH), text=True, capture_output=True)
    make_process = subprocess.Popen(['make'], cwd=os.path.dirname(M_FILE_PATH), text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    steps = 10
    current_step = 0

    while True:
        output = make_process.stdout.readline()
        if output == '' and make_process.poll() is not None:
            break
        if output:
            current_step += 1
            progress = int((current_step / steps) * 90)
            bot.edit_message_text(f"Đang Cày {progress} Phần Trăm Rồi, Ráng Đợi Nha Mày", chat_id=msg.chat.id, message_id=msg.message_id)
    make_process.communicate()

def send_dylib_file(message, msg, fps_name):
    dylib_path = os.path.join(os.path.dirname(M_FILE_PATH), '.theos', 'obj', 'debug', 'NguyenThanhHung.dylib')

    with open(dylib_path, 'rb') as dylib_file:
        bot.send_document(message.chat.id, dylib_file, caption=f"Xong, File dylib Đây, FPS Tên {fps_name} Cho Mày Đó", parse_mode="Markdown")
        bot.edit_message_text(f"Xong 100 Phần Trăm Rồi Nha, File Tao Gửi Rồi Đó, Check Đi Mày", chat_id=msg.chat.id, message_id=msg.message_id)

bot.polling()
